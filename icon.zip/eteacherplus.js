function dispatchByURL() {
    if (document.URL.indexOf("login.asp") !== -1) {
        //LOGIN PAGE

        autoLogin(document)
    } else if (document.URL.indexOf("reports/salary/courses.asp") !== -1) {
        //REPORT PAGE
        
        report()
    } else if (document.URL.indexOf("default.asp") !== -1) {
        //HOME PAGE
        displayPublisher()
    } else if (document.URL.indexOf("Materials.asp") !== -1) {
       //checkForAutoPublish()
    } else if (document.URL.indexOf("MyProfile.asp") !== -1) {
        myProfile()
    }
}

function myProfile() {
 const body = document.getElementById("UpdateTeacherDetails").parentNode
 var field = document.createElement("input")
 var button = document.createElement("button")
 button.innerHTML = "change password in eteacher+"
 console.log(localStorage.getItem("pwd"))
 button.onclick = () => {
    console.log(field.value)
    localStorage.setItem("pwd", field.value)
 }
 body.appendChild(field)
 body.appendChild(button)
}

function checkForAutoPublish() {
    browser.storage.local.get("publishContent").then(need => {
        if (need.publishContent) {
            let publishContent = false
            browser.storage.local.set({publishContent})
            var check = getLastPublishedOfClassObject(document, 1)
            check.checkbox.click()
            check.publish.click()
        }
    })
}

function displayPublisher() {
    var aTags = document.getElementsByTagName("TR");
    var searchText = "Build Your First";
    var searchText2 = "Scratch";
    var found = [];
    for (var i = 0; i < aTags.length; i++) {
        if (aTags[i].textContent.indexOf(searchText) !== -1 || aTags[i].textContent.indexOf(searchText2) !== -1) {
            if (aTags[i].cells.length === 4)
                found.push(aTags[i]);
        }
    }
    var d = new Date()
    console.log(localStorage.getItem("idClasses"))
    idClasses = new Map(JSON.parse(localStorage.getItem("idClasses")))
    console.log(idClasses)
    found.forEach(classe => {
        console.log(classe)
        var button = document.createElement("button");
        var className = classe.children[1].childNodes[0].textContent
        var lastPublished = getLastPublishedOfClass(idClasses.get(className), 1) 
        var today = (d.getDate() < 10 ? "0" + d.getDate() : d.getDate()) + "/" + ((d.getMonth() + 1) < 10 ? "0" + (d.getMonth() + 1) : (d.getMonth() + 1)) + "/" + d.getFullYear()
        let buttonValid = document.createElement("button")
        buttonValid.innerHTML = "Report"
        buttonValid.style.background = "#f4aa42"
        buttonValid.onclick = () => {
            window.open(getReportURL(), '_blank');
        }
        classe.children[3].appendChild(buttonValid)
        if (lastPublished.time === today) {
            button.innerHTML = lastPublished.nameOfPrevious
            button.style.background='#00aa00'
            button.onclick = () => {
                var win = window.open(getPublishContentURL(idClasses.get(className)), '_blank');
            }
        } else {
            button.innerHTML = lastPublished.name
            button.onclick = () => {
                let publishContent = true
                browser.storage.local.set({publishContent})
                var win = window.open(getPublishContentURL(idClasses.get(className)), '_blank');
                button.style.background='#00aa00'
            }           
        }
        classe.childNodes[1].appendChild(button)
    })
}

function autoLogin(document) {
    console.log("ici")
    username = document.getElementById("UserName")
    password = document.getElementById("Password")
    submit = document.getElementById("SubmitLoginForm")
    username.value = "blizzard120"
    password.value = localStorage.getItem("pwd")
    submit.click();

}

var HttpClient = function() {
    this.get = function(aUrl, aCallback) {
        var anHttpRequest = new XMLHttpRequest();
        anHttpRequest.onreadystatechange = function() { 
            if (anHttpRequest.readyState == 4 && anHttpRequest.status == 200)
                aCallback(anHttpRequest.responseText);
        }

        anHttpRequest.open( "GET", aUrl, true );            
        anHttpRequest.send( null );
    }
    this.getSync = function(theUrl, cookie) {
        var xmlHttp = new XMLHttpRequest();

        xmlHttp.open( "GET", theUrl, false );
        xmlHttp.send( null );
        return xmlHttp.responseText;
    }
}

function report() {
    var idTable = getIdTable()
    var reportTable = getReportTable(idTable)
    fillForClasses(reportTable)
    //document.getElementById("SubmitUpdateTeacherCourseSalaryFrm").click()
}

function fillForClasses(reportTable) {
    reportTable.forEach(classe => {
        classe.confirm.selectedIndex = 1
        classe.unitSelect.selectedIndex = getLastPublishedOfClass(classe.id).num;
    })
}

function getReportTable(idClasses) {
    var fullTab = document.getElementById("UpdateTeacherCourseSalaryFrm")
    var tabContent = [... fullTab.childNodes]
    tabContent = tabContent.find((obj) => obj.tagName === "TABLE")
    tabContent = [... tabContent.childNodes]
    tabContent = tabContent.find((obj) => obj.tagName === "TBODY")
    tabContent = [... tabContent.childNodes]
    tabContent = tabContent.filter((obj) => obj.tagName === "TR")
    tabContent.shift()
    tabContent.shift()
    tabContent.splice(-2, 2)
    var out = new Array();
    var i = 0;
    tabContent.forEach((obj, id) => {
        if ((id % 2) === 0) {
            out[i] = {id: null, confirm: null, unitSelect: null};
            out[i].id =  idClasses.get(obj.childNodes[1].childNodes[0].innerText)
        } else {
            out[i].confirm = obj.getElementsByTagName("SELECT")[0]
            out[i].unitSelect = obj.getElementsByTagName("SELECT")[3]
            i++;
        }
    })
    return out
}

function getIdTable() {
    var select = document.getElementById("CourseID")
    var idTable = [... select.childNodes]
    var idClasses = new Map()
    idTable.forEach((opt) => idClasses.set(opt.innerText, opt.getAttribute("value")));
    console.log("here")
    console.log(JSON.stringify(Array.from(idClasses.entries())))
    localStorage.setItem("idClasses", JSON.stringify(Array.from(idClasses.entries())))
    //browser.storage.local.set({idClasses})
    return idClasses
}

function getBaseURL() {
    var curURL = document.URL
    curURL = curURL.substring(0, curURL.indexOf("officeEX/")) + "officeEX/"
    return curURL
}

function getPublishContentURL(classId) {
    let url = getBaseURL() + "courses/OneCourse/Materials.asp?CourseID=" + classId
    return url
}

function getReportURL() {
    let url = getBaseURL() + "reports/salary/courses.asp"
    return url
}

function getLastPublishedOfClassObject(doc, skip = 0) {
    var checkboxs = doc.getElementById("PublishForm").getElementsByClassName("publish-unit")

    checkboxs = Array.prototype.slice.call( checkboxs )
    let lastPublished = checkboxs.find((o) => {
        return !o.hasAttribute("checked")
    })
    let parent = checkboxs[checkboxs.indexOf(lastPublished) - 1 + skip].parentNode;
    let name = parent.childNodes[1].textContent
    var previous = ""
    if (checkboxs[checkboxs.indexOf(lastPublished) - 2 + skip]) {
        previous = checkboxs[checkboxs.indexOf(lastPublished) - 2 + skip].parentNode.childNodes[1].textContent;
    }
    let time = checkboxs[checkboxs.indexOf(lastPublished) - 1].parentNode.parentElement.children[4].textContent
    let publish = doc.getElementById("SubmitPublishForm")
    let checkbox = checkboxs[checkboxs.indexOf(lastPublished) - 1 + skip]
    return {num :checkboxs.indexOf(lastPublished) + skip, name: name, nameOfPrevious : previous, time: time, publish : publish, checkbox : checkbox}
}

function getLastPublishedOfClass(classId, skip = 0) {
    let url = getPublishContentURL(classId)
    let client = new HttpClient();
    let response = client.getSync(url);
    let parser = new DOMParser();
    var htmlDoc = parser.parseFromString(response, 'text/html');
    return getLastPublishedOfClassObject(htmlDoc, skip)
}








dispatchByURL()
